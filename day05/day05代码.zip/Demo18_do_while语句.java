class Demo18_do_while��� {
	public static void main(String[] args) {
		int i = 1;
		do {
			System.out.println("Hello World!");
			i++;
		} while (i <= -5);
	}
}
