class Demo10_for��� {
	public static void main(String[] args) {
		//��ӡ5�ڴ�HelloWorld
		for (int i = 1; i <= 5 ; i++) {
			System.out.println("Hello World!");
		}

	}
}
