class Demo12_��ӡ����5��1 {
	public static void main(String[] args) {
		for (int i = 1; i <= 5; i++) {
			//i=1  5		6
			//i=2  4		6
			//i=3  3		6
			System.out.println(6 - i);
		}

		System.out.println("-------------------------");

		for (int i = 5; i >= 1; i--) {
			System.out.println(i);
		}
	}
}
