class Demo16_while��� {
	public static void main(String[] args) {
		int i = 1;
		while (i <= 5) {
			System.out.println("Hello World!");
			i++;
		}
	}
}
