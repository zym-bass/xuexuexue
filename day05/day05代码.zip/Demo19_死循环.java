class Demo19_��ѭ�� {
	public static void main(String[] args) {
		/*for ( ; ; ) {
			System.out.println("Hello World!");
		}*/

		while (true) {
			System.out.println("Hello World!");
		}

		
	}
}
