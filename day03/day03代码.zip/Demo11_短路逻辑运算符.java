class Demo11_��·�߼������ {
	public static void main(String[] args) {
		//��֤&&�Ķ�·�ص�
		int a = 10;
		System.out.println((a <= 5) & (a++ >= 8));
		System.out.println(a);//11

		int b = 20;
		System.out.println((b <= 5) && (b++ >= 8));
		System.out.println(b);//20

		System.out.println("-----------------------------");
		//��֤||�Ķ�·�ص�
		int c = 30;
		System.out.println((c >= 10) | (c++ <= 5));
		System.out.println(c);//31

		int d = 40;
		System.out.println((d >= 10) || (d++ <= 5));
		System.out.println(d);//40

	}
}
