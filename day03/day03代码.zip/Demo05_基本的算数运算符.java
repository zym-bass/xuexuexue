class Demo05_��������������� {
	public static void main(String[] args) {
		System.out.println(3 + 2);
		System.out.println(+666);

		System.out.println("Hello" + "World");

		System.out.println("Hello" + 666);

		int a = 888;
		System.out.println("Hello" + a);

		int i = 101;
		int j = 202;
		//i = 10, j = 20
		System.out.println("i = " + i + ", j = " + j);

		System.out.println("-------------------------");

		System.out.println(7 / 2);
		System.out.println(7.0 / 2);
		System.out.println(7 / 2.0);

		System.out.println("-------------------------");

		System.out.println(7 % 2);
		System.out.println(123 % 10);
		System.out.println((-123) % 10);
		System.out.println((-123) % (-10));
		System.out.println(123 % (-10));

	}
}
