class Demo06_�����Լ������ {
	public static void main(String[] args) {
		int a = 10;
		a++;
		System.out.println(a);

		a--;
		System.out.println(a);

		System.out.println("=================================");

		int i = 100;
		i++;
		System.out.println(i);

		++i;
		System.out.println(i);

		System.out.println("=================================");

		int j = 200;
		System.out.println(j++);
		System.out.println(j);

		System.out.println("=================================");

		int k = 300;
		System.out.println(++k);
		System.out.println(k);
	}
}