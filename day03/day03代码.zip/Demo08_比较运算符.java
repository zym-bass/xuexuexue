class Demo08_�Ƚ������ {
	public static void main(String[] args) {
		System.out.println(10 == 10);
		System.out.println(10 == 20);
		System.out.println(10 != 20);

		System.out.println(12.34 == 12.34);
		System.out.println(12.34 != 12.34);

		System.out.println('a' == 'b');

		System.out.println(false == true);

		System.out.println("Hello" == "hello");
		System.out.println("Hello" == "Hello");

		System.out.println("--------------------------------");

		System.out.println('a' > 'b');
		System.out.println('b' < 'c');
		System.out.println('a' < 'A');
		System.out.println('-' < '0');
		System.out.println(',' < '-');
	}
}
