class Demo03_���� {
	public static void main(String[] args) {
		int age = 23;
		System.out.println(age);

		age = 24;
		System.out.println(age);
	}
}
