class Demo01_λ����� {
	public static void main(String[] args) {
		int a = 20;
		int b = 30;
		System.out.println(a & b);
		System.out.println(a | b);
		System.out.println(a ^ b);//10

		System.out.println(a ^ b ^ b);//20�� a

		System.out.println(a ^ b ^ a);//b

		a = a ^ b;//a=10;b=30
		b = a ^ b;//a=10;b=20
		a = a ^ b;//a=30;b=20
		System.out.println("a=" + a + ", b=" + b);

		System.out.println(~b);
	}
}
