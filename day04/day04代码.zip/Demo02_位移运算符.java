class Demo02_λ������� {
	public static void main(String[] args) {
		byte i = 6;//00000110
		int bit = 7;
		i <<= bit;
		System.out.println(i);
		

		int j = 10;
		System.out.println(j >> 2);
		//00000010

		int k = -10;
		System.out.println(k >> 2);

		System.out.println(-5 / 2);

		System.out.println(10 >>> 2);

		System.out.println(-10 >>> 1);		
	}
}
